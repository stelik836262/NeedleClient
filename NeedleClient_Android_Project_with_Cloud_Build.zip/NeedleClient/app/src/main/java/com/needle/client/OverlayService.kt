package com.needle.client

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null

    private fun params(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "N"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(112, 65, 190))
            setOnClickListener { showPanel() }
        }
        bubble = b
        val p = params(54, 54)
        p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.addView(b, p)
        makeDraggable(b, p)
    }

    private fun showPanel() {
        if (panel != null) return
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(24, 23, 33))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "NEEDLE CLIENT  •  1.0"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(194, 155, 255))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val minimize = TextView(this).apply {
            text = "—"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(14, 4, 8, 4)
            setOnClickListener { hidePanelToBubble() }
        }
        header.addView(title); header.addView(minimize)
        box.addView(header)

        val tabs = listOf("Combat", "Movement", "Render", "Player", "Misc")
        tabs.forEach { name ->
            val row = TextView(this).apply {
                text = "$name     •     Пока пусто"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(12, 13, 12, 13)
                setBackgroundColor(Color.rgb(39, 36, 52))
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = 8
            box.addView(row, lp)
        }
        val note = TextView(this).apply {
            text = "Интерфейс-компаньон. Игровые функции отключены."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(4, 14, 4, 0)
        }
        box.addView(note)

        panel = box
        val p = params(300, -2).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        panelParams = p
        wm.addView(box, p)
        makeDraggable(box, p)
    }

    private fun hidePanelToBubble() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelParams = null
        showBubble()
    }

    private fun makeDraggable(view: View, p: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = event.rawX; touchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX - touchX).toInt()
                    p.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
