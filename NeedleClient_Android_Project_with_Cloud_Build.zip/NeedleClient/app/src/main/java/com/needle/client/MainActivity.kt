package com.needle.client

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 18, 25))
        }
        val title = TextView(this).apply {
            text = "NEEDLE CLIENT"
            textSize = 27f
            setTextColor(Color.rgb(190, 140, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Bedrock companion overlay • v1.0\nПока только интерфейс — без игровых функций."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val button = Button(this).apply {
            text = "Разрешить оверлей и запустить"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(button)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        // После возврата из системных настроек пользователь может нажать кнопку запуска.
    }
}
